//
//  ChoiceCharacters.swift
//  ObitoApp
//
//  Created by Rayann chaghla on 24/02/2025.
//

import SwiftUI

struct ChoiceCharacter: View {
    
    let obito: ObitoEvolution
    
    
    
    
    @State private var selectionCharacter = false
    
    var body: some View {
        
        Button("Choisis un ninja ! "){
            selectionCharacter.toggle()
        }
        .padding()
        .background(Color.blue)
        .foregroundColor(.white)
        .cornerRadius(10)
        .popover(isPresented: $selectionCharacter, attachmentAnchor: .point(.top)) {
            ZStack {
                Color.black
                    .ignoresSafeArea()
                GeometryReader { geometry in
                    TabView() {
                        ForEach(obitos) { obito in
                            VStack(spacing: 3){
                                Text("\(obito.nameObito) : ")
                                    .font(.title)
                                    .foregroundColor(.white)
                                    .padding()
                                Text(obito.ageObito.description + " ans")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                Spacer()
                                VStack {
                                    ObitoCardView(obito: obito)
                                    
                                    Text(obito.descriptionObito)
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                }
                                Spacer()
                                
                            }
                        }
                    }
                    
                    .tabViewStyle(PageTabViewStyle())
                    .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                }
            }
            // Fin de ma ZStack
            
        }
        // Fin de ma Popover
    }
      
        
}

#Preview {
    ChoiceCharacter(obito: obitos[1])
}
