//
//  ObitoAppApp.swift
//  ObitoApp
//
//  Created by Rayann chaghla on 24/02/2025.
//

import SwiftUI

@main
struct ObitoAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
